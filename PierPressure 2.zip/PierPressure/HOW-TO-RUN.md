# How to run the dress-up game

The clothing only appears **on** the model when the game loads the image files from the correct place. Do one of the following:

## Option 1: Open the file from the right folder

1. In Finder (Mac) or File Explorer (Windows), go to the **Website** folder (the one that contains `index.html` and the `assets` folder).
2. Double-click **index.html** to open it in your browser.

Do **not** open `index.html` from inside another folder or from a path that doesn’t include the `assets` folder as a sibling of `index.html`.

## Option 2: Use a local server (recommended)

1. Open Terminal (Mac/Linux) or Command Prompt (Windows).
2. Go to the **Website** folder:
   ```bash
   cd path/to/Website
   ```
   (Replace `path/to/Website` with your actual path, e.g. `cd ~/Desktop/Website`.)
3. Start a simple server:
   - **Python 3:** `python3 -m http.server 8000`
   - **Python 2:** `python -m SimpleHTTPServer 8000`
   - **Node (npx):** `npx serve .`
4. In your browser, open: **http://localhost:8000** (or the URL the server prints).

Then click **Blue jacket**, **Plaid skirt**, or **Combat boots** — the item should appear on the character in the left panel.

## If the image opens in a new tab

If clicking a wardrobe button opens the image in a new tab instead of putting it on the model, you’re likely opening the page from the wrong path (so the script can’t find the layers). Use Option 1 or 2 above so `index.html` and `assets` are in the right place.
