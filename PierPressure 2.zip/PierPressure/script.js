/**
 * Style Studio — dress-up: clothing on the model, black backgrounds made transparent.
 */
(function () {
  var ASSETS = {
    blouse: 'assets/jacket-blue.png',
    skirt: 'assets/skirt-plaid.png',
    boots: 'assets/combat-boots.png'
  };

  var transparentCache = {};
  var BLACK_THRESHOLD = 50;

  function getLayer(slot) {
    return document.getElementById('layer-' + slot);
  }

  function fullUrl(path) {
    try {
      return new URL(path, window.location.href).href;
    } catch (e) {
      return path;
    }
  }

  function makeBlackTransparent(imageUrl, done) {
    if (transparentCache[imageUrl]) {
      done(transparentCache[imageUrl]);
      return;
    }
    var img = new Image();
    if (window.location.protocol !== 'file:') {
      img.crossOrigin = 'anonymous';
    }
    img.onload = function () {
      var w = img.naturalWidth;
      var h = img.naturalHeight;
      var canvas = document.createElement('canvas');
      canvas.width = w;
      canvas.height = h;
      var ctx = canvas.getContext('2d');
      ctx.drawImage(img, 0, 0);
      try {
        var data = ctx.getImageData(0, 0, w, h);
        var p = data.data;
        for (var i = 0; i < p.length; i += 4) {
          if (p[i] <= BLACK_THRESHOLD && p[i + 1] <= BLACK_THRESHOLD && p[i + 2] <= BLACK_THRESHOLD) {
            p[i + 3] = 0;
          }
        }
        ctx.putImageData(data, 0, 0);
        var dataUrl = canvas.toDataURL('image/png');
        transparentCache[imageUrl] = dataUrl;
        done(dataUrl);
      } catch (err) {
        done(imageUrl);
      }
    };
    img.onerror = function () {
      done(imageUrl);
    };
    img.src = imageUrl;
  }

  function setLayerBackground(layer, url) {
    layer.style.backgroundImage = url ? 'url(' + url + ')' : '';
    layer.style.backgroundSize = 'contain';
    layer.style.backgroundPosition = 'center';
    layer.style.backgroundRepeat = 'no-repeat';
  }

  function clearLayerBackground(layer) {
    layer.style.backgroundImage = '';
    layer.style.backgroundSize = '';
    layer.style.backgroundPosition = '';
    layer.style.backgroundRepeat = '';
  }

  var worn = { top: null, bottom: null, shoes: null };

  function wear(slot, itemId) {
    var layer = getLayer(slot);
    if (!layer) return;

    if (itemId && ASSETS[itemId]) {
      var path = ASSETS[itemId];
      var url = fullUrl(path);
      makeBlackTransparent(url, function (finalUrl) {
        setLayerBackground(layer, finalUrl);
      });
    } else {
      clearLayerBackground(layer);
    }
    worn[slot] = itemId || null;
    updateButtons();
  }

  function toggle(slot, itemId) {
    if (worn[slot] === itemId) {
      wear(slot, null);
    } else {
      wear(slot, itemId);
    }
  }

  function updateButtons() {
    var buttons = document.querySelectorAll('.item-btn');
    for (var i = 0; i < buttons.length; i++) {
      var btn = buttons[i];
      var slot = btn.getAttribute('data-slot');
      var id = btn.getAttribute('data-id');
      btn.classList.toggle('on', worn[slot] === id);
    }
  }

  function init() {
    var resetBtn = document.getElementById('btn-reset');
    if (resetBtn) {
      resetBtn.addEventListener('click', function () {
        wear('top', null);
        wear('bottom', null);
        wear('shoes', null);
      });
    }

    var btns = document.querySelectorAll('.item-btn');
    for (var j = 0; j < btns.length; j++) {
      (function (btn) {
        btn.addEventListener('click', function (e) {
          e.preventDefault();
          var slot = btn.getAttribute('data-slot');
          var id = btn.getAttribute('data-id');
          if (slot && id) toggle(slot, id);
        });
      })(btns[j]);
    }

    updateButtons();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
