# Real Assets Guide — Style Studio Dress-Up Game

This guide explains how to use **real image assets** (PNG/SVG) for the base model, hair, and clothing so your game looks like the reference (Stardoll-style, high-quality layered art).

---

## 1. How the game uses assets

- **Base model:** One image (PNG or SVG) for the character body in a fixed pose.  
  Path is set in `assets/manifest.json` as `"base"` or falls back to `assets/base-body.svg`.

- **Layers:** Each category (hair, dress, top, bottom, shoes, accessory) can use **image files** instead of code-drawn graphics:
  - **layerPath** — image shown on the model when the item is worn.
  - **thumbPath** — image shown in the item list (optional; if missing, `layerPath` is used).

- **Format:** Use **PNG with transparency** or **SVG**. Same size and registration for all layers so they line up on the model.

---

## 2. Recommended image specs (for real assets)

Use one consistent “canvas” size for every layer so they align:

| Spec | Value | Notes |
|------|--------|------|
| **Width** | 200 px | Or 400 px if you want higher resolution (scale in CSS if needed). |
| **Height** | 400 px | Matches current base proportion (1:2). |
| **Format** | PNG-24 with alpha, or SVG | Transparency required. |
| **Registration** | Same for all layers | Pivot at center-bottom or center-top so the figure lines up. |

- **Base:** Full body, single pose (e.g. T-pose or your chosen pose). No clothes/hair; just skin/base.
- **Hair:** Same canvas; draw hair only; leave face/body transparent (or use a mask) so the base shows through.
- **Clothes:** Same canvas; draw the garment only; transparent everywhere else.
- **Thumbnails:** Can be the same file as the layer, or a smaller crop (e.g. 64×64 or 128×128) for the right-hand list.

---

## 3. Using the manifest for real assets

Edit **`assets/manifest.json`** to point to your PNGs (or SVGs).

**Base model:**

```json
"base": "assets/base.png"
```

**Hair / Dresses (and other categories if you add them):**

```json
"hair": [
  { "id": "hair-none", "name": "None", "layerPath": null, "thumbPath": null },
  { "id": "hair-long", "name": "Long straight", "layerPath": "assets/hair/long-straight.png", "thumbPath": "assets/hair/thumbs/long-straight.png" }
],
"dress": [
  { "id": "dress-mini", "name": "Mini dress", "layerPath": "assets/dresses/mini-dress.png", "thumbPath": "assets/dresses/mini-dress.png" }
]
```

- **id** — unique id used in the game (e.g. for presets).
- **name** — label shown in UI if you add it.
- **layerPath** — path to the full-size layer image (PNG/SVG).
- **thumbPath** — optional; path to thumbnail; if omitted, the game uses `layerPath` for the list.

Place your files under `assets/` (e.g. `assets/hair/`, `assets/dresses/`) and keep paths in the manifest relative to the project root.

---

## 4. Turning current SVGs into PNGs

If you want to keep the current look but use PNGs:

1. Open each SVG in a vector app (Figma, Illustrator, Inkscape) or in the browser.
2. Set artboard/canvas to **200×400** (or your chosen size).
3. Export as **PNG**, 1x or 2x, with transparency.
4. Put the PNGs in the right folders and update **`manifest.json`** to use the new paths (e.g. `assets/hair/long-straight.png`).

No code changes are needed as long as paths in the manifest are correct.

---

## 5. Sourcing or commissioning real assets

To get a “real assets” look like the reference:

- **Asset packs:** Search itch.io, OpenGameArt, or similar for “dress up game”, “paper doll”, “character layers”. Pre-made packs often include base + hair + clothes; you may need to resize/crop to 200×400 and match your pose.
- **AI image generation:** Use a consistent character sheet prompt (same pose, same style) and generate base, then hair, then each clothing layer. Export at 200×400 (or 400×800) with transparency. Consistency across layers is the main challenge.
- **Commission an artist:** Provide:
  - One base character (pose and proportions).
  - A list of layers: hair 1–5, tops, bottoms, dresses, shoes, accessories.
  - Specs: 200×400 px, PNG with transparency, same registration.
  - Style reference (e.g. Stardoll / teen fashion game screenshot).

---

## 6. Adding PNGs for tops, bottoms, shoes, accessories

The manifest currently defines **base**, **hair**, and **dress**. Tops, bottoms, shoes, and accessories are still defined in **`script.js`** (e.g. in `WARDROBE`).

To use PNGs for those too:

1. Add the PNG (and optional thumb) to `assets/` (e.g. `assets/tops/tee-white.png`).
2. In `script.js`, give the item an **assetPath** (and optional **thumbPath**):

```js
{ id: 'tee-white', name: 'White tee', slot: 'top', color: '#fff', assetPath: 'assets/tops/tee-white.png', thumbPath: 'assets/tops/thumbs/tee-white.png', layer: topTee },
```

- If **assetPath** (or **layerPath**) is set, the game uses the image for that layer.
- If not, it uses the **layer** function (current drawn SVG). So you can mix PNGs and code-drawn items.

You can later move these into **manifest.json** (e.g. add `"top"`, `"bottom"`, `"shoes"`, `"accessory"` arrays) and load them the same way as hair/dress if you want everything configurable without editing script.

---

## 7. Folder structure example

```
assets/
  manifest.json
  base-body.svg          (or base.png)
  base.png              (your real base asset)
  hair/
    long-straight.png
    wavy.png
    thumbs/
      long-straight.png
  dresses/
    mini-dress.png
    midi-dress.png
  tops/
    tee-white.png
  bottoms/
    jeans.png
  shoes/
    sneakers.png
  accessories/
    sunglasses.png
```

Use **manifest.json** for base, hair, and dress paths; use **script.js** (or a future manifest extension) for top/bottom/shoes/accessory paths. Keep paths relative to the project root so the game can load them.

---

## 8. Quick checklist for “real assets”

- [ ] One base model image (PNG/SVG), 200×400 (or your chosen size), transparent.
- [ ] One image per hair style, same size, transparent (face/body cut out or masked).
- [ ] One image per clothing item (tops, bottoms, dresses, shoes, accessories), same size, transparent.
- [ ] Optional: separate thumbnails for the right-hand list.
- [ ] Update **`assets/manifest.json`** for base, hair, and dress.
- [ ] For tops/bottoms/shoes/accessories, add **assetPath** (and optional **thumbPath**) in **script.js** (or in manifest if you extend it).
- [ ] Serve the game from the project root (or fix paths) so `assets/...` URLs load correctly.

Once your files and paths are set, the game will use your real assets for the base model, hair, and clothes like in the reference.
